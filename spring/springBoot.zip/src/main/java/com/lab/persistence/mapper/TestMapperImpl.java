package com.lab.persistence.mapper;

import com.lab.persistence.mapper.bbdd.BBDD;
import com.lab.persistence.model.TestModel;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


@Repository
public class TestMapperImpl implements TestMapper
{

  @Autowired
  BBDD db;


  @Override
  public List<TestModel> testMapper(TestModel obj) throws Exception
  {

    List<TestModel> x = new ArrayList<>();
    TestModel m = new TestModel();
    List<String> data = new ArrayList<>();
    
    /**
     * CONECTANDO A LA BBDD.
     */
    db.conecta();

    /**
     * RECORRIENDO LAS TABLAS.
     */
    for (int i = 0; i < db.tablas().size(); i++)
    {
      m.setTable(db.tablas().get(i));

      /**
       * RECORRIENDO LAS COLUMNAS DE LA TABLA SELECCIONADA.
       */
      for (int j = 0; j < db.columnas(db.tablas().get(i)).size(); j++)
      {
        m.setColum(db.columnas(db.tablas().get(i)).get(j));

        /**
         * CONSULTANDO LOS VALORES DE LA COLUMNA SELECCIONADA.
         */
        ResultSet rs = db.consulta("SELECT * FROM " + db.tablas().get(i));
        while (rs.next())
        {
          data.add(db.columnas(db.tablas().get(i)).get(j));
        }

        m.setData(data);
      }

      x.add(m);
    }

    /**
     * DESCONECTANDO A LA BBDD.
     */
    db.desconecta();

    return x;
  }

}
