package com.lab.persistence.model;

import java.util.ArrayList;
import java.util.List;


public class TestModel
{

  private String table;
  private String colum;
  private List<String> data;


  public String getTable()
  {
    return table;
  }


  public void setTable(String table)
  {
    this.table = table;
  }


  public String getColum()
  {
    return colum;
  }


  public void setColum(String colum)
  {
    this.colum = colum;
  }


  public List<String> getData()
  {
    return data;
  }


  public void setData(List<String> data)
  {
    this.data = data;
  }


}
